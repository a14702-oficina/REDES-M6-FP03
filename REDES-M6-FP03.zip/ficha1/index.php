<?php
session_start();

// Se o utilizador não estiver logado, redireciona para a página de login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include 'config/ligacao.php';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestão de Infraestrutura de Rede Escolar</title>
    <link rel="stylesheet" href="style.css?v=1.0">
    <style>
        .user-info {
            text-align: right;
            padding: 10px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ddd;
        }
        .logout-btn {
            color: #e74c3c;
            text-decoration: none;
            font-weight: bold;
            margin-left: 10px;
        }
        .logout-btn:hover {
            text-decoration: underline;
        }
        .error-banner {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            text-align: center;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
        }
        /* Estilo para o novo card de admin */
        .menu-card.admin {
            background-color: #2c3e50;
            color: white;
        }
        .menu-card.admin:hover {
            background-color: #34495e;
        }
    </style>
</head>
<body>
    <div class="user-info">
        Olá, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong> (<?php echo htmlspecialchars($_SESSION['role']); ?>) | 
        <a href="logout.php" class="logout-btn">Sair</a>
    </div>

    <div class="container">
        <h1>Sistema de Gestão de Infraestrutura de Rede Escolar</h1>
        
        <?php if (isset($_GET['erro_acesso'])): ?>
            <div class="error-banner">
                Você não tem permissão para aceder a essa página.
            </div>
        <?php endif; ?>

        <p style="text-align: center; color: #7f8c8d; margin-bottom: 30px;">
            Bem-vindo ao sistema de gestão de infraestrutura de rede. Selecione uma opção abaixo para começar.
        </p>
        
        <div class="menu-principal">
            <a href="pages/salas.php" class="menu-card salas">
                <h2>🏫 Gestão de Salas</h2>
                <p>Visualizar e adicionar salas da escola</p>
            </a>
            
            <a href="pages/equipamentos.php" class="menu-card equipamentos">
                <h2>🖥️ Gestão de Equipamentos</h2>
                <p>Gerenciar routers, switches e access points</p>
            </a>
            
            <?php if ($_SESSION['role'] === 'Administrador'): ?>
            <a href="pages/tecnicos.php" class="menu-card tecnicos">
                <h2>👨‍💼 Gestão de Técnicos</h2>
                <p>Registar e consultar técnicos responsáveis</p>
            </a>
            
            
            <?php endif; ?>
            
            <a href="pages/intervencoes.php" class="menu-card intervencoes">
                <h2>🔧 Registo de Intervenções</h2>
                <p>Registar intervenções técnicas realizadas</p>
            </a>
            
            <a href="pages/equipamentos_sem_intervencoes.php" class="menu-card equipamentos-sem">
                <h2>📋 Equipamentos sem Intervenções</h2>
                <p>Listar equipamentos que nunca foram intervencionados</p>
            </a>
        </div>
    
    </div>
</body>
</html>
