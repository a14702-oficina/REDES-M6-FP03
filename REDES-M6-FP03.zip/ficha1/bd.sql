CREATE TABLE IF NOT EXISTS salas (
    id_sala INT AUTO_INCREMENT PRIMARY KEY,
    nome_sala VARCHAR(100) NOT NULL,
    localizacao VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS equipamentos (
    id_equipamento INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('router', 'switch', 'AP', 'outro') NOT NULL,
    marca VARCHAR(100) NOT NULL,
    modelo VARCHAR(100) NOT NULL,
    endereco_ip VARCHAR(45) NOT NULL,
    id_sala INT,
    FOREIGN KEY (id_sala) REFERENCES salas(id_sala) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS tecnicos (
    id_tecnico INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    contacto VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS intervencoes (
    id_intervencao INT AUTO_INCREMENT PRIMARY KEY,
    data_intervencao DATE NOT NULL,
    descricao TEXT NOT NULL,
    id_equipamento INT NOT NULL,
    id_tecnico INT NOT NULL,
    FOREIGN KEY (id_equipamento) REFERENCES equipamentos(id_equipamento) ON DELETE CASCADE,
    FOREIGN KEY (id_tecnico) REFERENCES tecnicos(id_tecnico) ON DELETE CASCADE
);

-- Inserir dados iniciais para teste
INSERT INTO salas (nome_sala, localizacao) VALUES 
('Sala 101', 'Bloco A, Piso 1'),
('Sala 202', 'Bloco B, Piso 2'),
('Data Center', 'Bloco C, Piso 0');

INSERT INTO equipamentos (tipo, marca, modelo, endereco_ip, id_sala) VALUES 
('router', 'Cisco', 'ISR 4331', '192.168.1.1', 3),
('switch', 'HP', 'Aruba 2930F', '192.168.1.2', 3),
('AP', 'Ubiquiti', 'UniFi AC Pro', '192.168.1.10', 1),
('AP', 'Ubiquiti', 'UniFi AC Pro', '192.168.1.11', 2),
('outro', 'APC', 'Smart-UPS 1500', '192.168.1.50', 3);

INSERT INTO tecnicos (nome, email, contacto) VALUES 
('João Silva', 'joao.silva@escola.pt', '912345678'),
('Maria Santos', 'maria.santos@escola.pt', '923456789');

INSERT INTO intervencoes (data_intervencao, descricao, id_equipamento, id_tecnico) VALUES 
('2026-02-10', 'Configuração inicial do router', 1, 1),
('2026-02-12', 'Atualização de firmware do switch', 2, 2),
('2026-02-15', 'Substituição de cabo de rede no AP da Sala 101', 3, 1);
