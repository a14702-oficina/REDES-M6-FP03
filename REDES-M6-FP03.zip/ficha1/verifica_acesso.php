<?php
session_start();

// Se o utilizador não estiver logado, redireciona para a página de login
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Função para verificar permissões
function verificarPermissao($roles_permitidas) {
    if (!isset($_SESSION["role"]) || !in_array($_SESSION["role"], $roles_permitidas)) {
        // Redireciona para uma página de acesso negado ou para a página principal com mensagem de erro
        header("Location: ../index.php?erro_acesso=true"); // Pode ser uma página de erro dedicada
        exit();
    }
}
?>
