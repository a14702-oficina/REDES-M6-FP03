<?php
try {
  $pdo = new PDO("mysql:host=sql300.infinityfree.com;dbname=if0_40156181_escola_rede;charset=utf8", "if0_40156181", "3lxGnvbpQ1rU3");
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Erro na ligação: " . $e->getMessage());
}
?>

<?php
// Configuração da ligação à base de dados

define('DB_HOST', 'sql300.infinityfree.com');
define('DB_USER', 'if0_40156181');
define('DB_PASS', '3lxGnvbpQ1rU3');
define('DB_NAME', 'if0_40156181_escola_rede');

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Verificar conexão
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }
    
    // Definir charset para UTF-8
    $conn->set_charset("utf8mb4");
    
} catch (Exception $e) {
    die("Erro ao conectar à base de dados: " . $e->getMessage());
}
?>
