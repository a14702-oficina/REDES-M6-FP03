<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include '../config/ligacao.php';

$isAdmin = (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrador');

$mensagem = '';
$filtro_tipo = isset($_GET['filtro']) ? $_GET['filtro'] : 'todas';
$filtro_valor = isset($_GET['valor']) ? intval($_GET['valor']) : 0;

// Processar inserção usando a coluna 'criado_por'
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'inserir') {
    $data_intervencao = trim($_POST['data_intervencao']);
    $descricao = trim($_POST['descricao']);
    $id_equipamento = intval($_POST['id_equipamento']);
    $id_tecnico = intval($_POST['id_tecnico']);
    $criado_por = intval($_SESSION['user_id']); // Pega o ID do utilizador logado

    if (empty($data_intervencao) || empty($descricao) || $id_equipamento == 0 || $id_tecnico == 0) {
        $mensagem = '<div class="erro">Todos os campos são obrigatórios!</div>';
    } else {
        $sql = "INSERT INTO intervencoes (data_intervencao, descricao, id_equipamento, id_tecnico, criado_por) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssiii", $data_intervencao, $descricao, $id_equipamento, $id_tecnico, $criado_por);
        
        if ($stmt->execute()) {
            $mensagem = '<div class="sucesso">Intervenção registada com sucesso!</div>';
        } else {
            $mensagem = '<div class="erro">Erro ao registar intervenção: ' . $conn->error . '</div>';
        }
        $stmt->close();
    }
}

// Obter listas para dropdowns
$sql_eq = "SELECT id_equipamento, marca, modelo FROM equipamentos ORDER BY marca";
$result_eq = $conn->query($sql_eq);
$equipamentos = [];
if ($result_eq->num_rows > 0) while ($row = $result_eq->fetch_assoc()) $equipamentos[] = $row;

$sql_tec = "SELECT id_tecnico, nome FROM tecnicos ORDER BY nome";
$result_tec = $conn->query($sql_tec);
$tecnicos = [];
if ($result_tec->num_rows > 0) while ($row = $result_tec->fetch_assoc()) $tecnicos[] = $row;

// Obter lista de intervenções, incluindo o nome de quem criou
$base_sql = "SELECT i.id_intervencao, i.data_intervencao, i.descricao, 
                    e.marca, e.modelo, 
                    t.nome AS tecnico_nome,
                    u.username AS criado_por_nome
             FROM intervencoes i 
             JOIN equipamentos e ON i.id_equipamento = e.id_equipamento 
             JOIN tecnicos t ON i.id_tecnico = t.id_tecnico
             LEFT JOIN utilizadores u ON i.criado_por = u.id";

if ($filtro_tipo == 'equipamento' && $filtro_valor > 0) {
    $sql = $base_sql . " WHERE i.id_equipamento = ? ORDER BY i.data_intervencao DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $filtro_valor);
    $stmt->execute();
    $result = $stmt->get_result();
} elseif ($filtro_tipo == 'tecnico' && $filtro_valor > 0) {
    $sql = $base_sql . " WHERE i.id_tecnico = ? ORDER BY i.data_intervencao DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $filtro_valor);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = $base_sql . " ORDER BY i.data_intervencao DESC";
    $result = $conn->query($sql);
}

$intervencoes = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $intervencoes[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registo de Intervenções</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Registo de Intervenções</h1>
        <a href="../index.php" class="btn-voltar">← Voltar ao Menu</a>
        
        <?php echo $mensagem; ?>
        
        <!-- Formulário de Inserção (Agora incluído) -->
        <div class="formulario-section">
            <h2>Registar Nova Intervenção</h2>
            <form method="POST" class="formulario" action="">
                <input type="hidden" name="acao" value="inserir">
                
                <div class="form-group">
                    <label for="data_intervencao">Data da Intervenção:</label>
                    <input type="date" id="data_intervencao" name="data_intervencao" required>
                </div>
                
                <div class="form-group">
                    <label for="id_equipamento">Equipamento:</label>
                    <select id="id_equipamento" name="id_equipamento" required>
                        <option value="">Selecione um equipamento</option>
                        <?php foreach ($equipamentos as $eq): ?>
                            <option value="<?php echo $eq['id_equipamento']; ?>">
                                <?php echo htmlspecialchars($eq['marca'] . ' ' . $eq['modelo']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="id_tecnico">Técnico Responsável:</label>
                    <select id="id_tecnico" name="id_tecnico" required>
                        <option value="">Selecione um técnico</option>
                        <?php foreach ($tecnicos as $tec): ?>
                            <option value="<?php echo $tec['id_tecnico']; ?>">
                                <?php echo htmlspecialchars($tec['nome']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <textarea id="descricao" name="descricao" rows="4" required></textarea>
                </div>
                
                <button type="submit" class="btn-submit">Registar Intervenção</button>
            </form>
        </div>
        
        <!-- Filtros (Agora incluídos) -->
        <div class="filtro-section">
            <h2>Filtrar Intervenções</h2>
            <form method="GET" class="filtro" action="">
                <select name="filtro" onchange="this.form.submit()">
                    <option value="todas" <?php echo ($filtro_tipo == 'todas') ? 'selected' : ''; ?>>Todas as intervenções</option>
                    <option value="equipamento" <?php echo ($filtro_tipo == 'equipamento') ? 'selected' : ''; ?>>Por Equipamento</option>
                    <option value="tecnico" <?php echo ($filtro_tipo == 'tecnico') ? 'selected' : ''; ?>>Por Técnico</option>
                </select>
                
                <?php if ($filtro_tipo == 'equipamento'): ?>
                    <select name="valor" onchange="this.form.submit()">
                        <option value="">Selecione um equipamento</option>
                        <?php foreach ($equipamentos as $eq): ?>
                            <option value="<?php echo $eq['id_equipamento']; ?>" 
                                <?php echo ($filtro_valor == $eq['id_equipamento']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($eq['marca'] . ' ' . $eq['modelo']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php elseif ($filtro_tipo == 'tecnico'): ?>
                    <select name="valor" onchange="this.form.submit()">
                        <option value="">Selecione um técnico</option>
                        <?php foreach ($tecnicos as $tec): ?>
                            <option value="<?php echo $tec['id_tecnico']; ?>" 
                                <?php echo ($filtro_valor == $tec['id_tecnico']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($tec['nome']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </form>
        </div>
        
        <div class="tabela-section">
            <h2>Lista de Intervenções</h2>
            <?php if (count($intervencoes) > 0): ?>
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Data</th>
                            <th>Equipamento</th>
                            <th>Técnico</th>
                            <th>Descrição</th>
                            <?php if ($isAdmin): ?>
                                <th>Criado por</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($intervencoes as $int): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($int['id_intervencao']); ?></td>
                                <td><?php echo htmlspecialchars(date('d/m/Y', strtotime($int['data_intervencao']))); ?></td>
                                <td><?php echo htmlspecialchars($int['marca'] . ' ' . $int['modelo']); ?></td>
                                <td><?php echo htmlspecialchars($int['tecnico_nome']); ?></td>
                                <td><?php echo htmlspecialchars($int['descricao']); ?></td>
                                <?php if ($isAdmin): ?>
                                    <td><?php echo htmlspecialchars($int['criado_por_nome'] ?? 'Desconhecido'); ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhuma intervenção registada.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
