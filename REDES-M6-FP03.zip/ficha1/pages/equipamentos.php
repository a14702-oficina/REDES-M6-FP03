<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start(); // Inicia a sessão

// --- VERIFICAÇÃO DE SEGURANÇA ---
// Se não houver um 'user_id' na sessão, significa que ninguém fez login.
// Redireciona para a página de login.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Ajuste o caminho se necessário
    exit(); // Garante que o resto do script não é executado
}

include '../config/ligacao.php'; // Inclui a ligação à base de dados

// --- LÓGICA DE PERMISSÕES ---
// Verifica se o utilizador logado é um 'Administrador'.
// Esta variável ($isAdmin) será usada para mostrar ou esconder a coluna.
$isAdmin = (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrador');

$mensagem = '';
$sala_filtro = isset($_GET['sala']) ? intval($_GET['sala']) : '';

// Processar inserção de equipamento
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'inserir') {
    $tipo = trim($_POST['tipo']);
    $marca = trim($_POST['marca']);
    $modelo = trim($_POST['modelo']);
    $endereco_ip = trim($_POST['endereco_ip']);
    $id_sala = intval($_POST['id_sala']);
    $criado_por = intval($_SESSION['user_id']); // ID do utilizador logado
    
    if (empty($tipo) || empty($marca) || empty($modelo) || empty($endereco_ip)) {
        $mensagem = '<div class="erro">Todos os campos são obrigatórios!</div>';
    } else {
        $sql = "INSERT INTO equipamentos (tipo, marca, modelo, endereco_ip, id_sala, criado_por) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssii", $tipo, $marca, $modelo, $endereco_ip, $id_sala, $criado_por);
        
        if ($stmt->execute()) {
            $mensagem = '<div class="sucesso">Equipamento inserido com sucesso!</div>';
        } else {
            $mensagem = '<div class="erro">Erro ao inserir equipamento: ' . htmlspecialchars($conn->error) . '</div>';
        }
        $stmt->close();
    }
}

// Obter lista de salas para o dropdown de filtro
$sql_salas = "SELECT id_sala, nome_sala FROM salas ORDER BY nome_sala";
$result_salas = $conn->query($sql_salas);
$salas = [];
if ($result_salas->num_rows > 0) {
    while ($row = $result_salas->fetch_assoc()) {
        $salas[] = $row;
    }
}

// Obter lista de equipamentos (com nome da sala e nome de quem criou)
if ($sala_filtro) {
    $sql = "SELECT e.id_equipamento, e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala, u.username AS criado_por_nome
            FROM equipamentos e
            LEFT JOIN salas s ON e.id_sala = s.id_sala
            LEFT JOIN utilizadores u ON e.criado_por = u.id
            WHERE e.id_sala = ?
            ORDER BY e.tipo, e.marca";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $sala_filtro);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT e.id_equipamento, e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala, u.username AS criado_por_nome
            FROM equipamentos e
            LEFT JOIN salas s ON e.id_sala = s.id_sala
            LEFT JOIN utilizadores u ON e.criado_por = u.id
            ORDER BY s.nome_sala, e.tipo";
    $result = $conn->query($sql);
}

$equipamentos = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $equipamentos[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Gestão de Equipamentos</title>
    <link rel="stylesheet" href="../style.css" />
</head>
<body>
    <div class="container">
        <h1>Gestão de Equipamentos</h1>
        <a href="../index.php" class="btn-voltar">← Voltar ao Menu</a>
        
        <?php echo $mensagem; ?>
        
        <div class="formulario-section">
            <h2>Inserir Novo Equipamento</h2>
            <form method="POST" class="formulario">
                <input type="hidden" name="acao" value="inserir" />
                
                <div class="form-group">
                    <label for="tipo">Tipo:</label>
                    <select id="tipo" name="tipo" required>
                        <option value="">Selecione um tipo</option>
                        <option value="router">Router</option>
                        <option value="switch">Switch</option>
                        <option value="AP">Access Point (AP)</option>
                        <option value="outro">Outro</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="marca">Marca:</label>
                    <input type="text" id="marca" name="marca" required />
                </div>
                
                <div class="form-group">
                    <label for="modelo">Modelo:</label>
                    <input type="text" id="modelo" name="modelo" required />
                </div>
                
                <div class="form-group">
                    <label for="endereco_ip">Endereço IP:</label>
                    <input type="text" id="endereco_ip" name="endereco_ip" placeholder="ex: 192.168.1.1" required />
                </div>
                
                <div class="form-group">
                    <label for="id_sala">Sala:</label>
                    <select id="id_sala" name="id_sala" required>
                        <option value="">Selecione uma sala</option>
                        <?php foreach ($salas as $sala): ?>
                            <option value="<?php echo $sala['id_sala']; ?>">
                                <?php echo htmlspecialchars($sala['nome_sala']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" class="btn-submit">Inserir Equipamento</button>
            </form>
        </div>
        
        <div class="filtro-section">
            <h2>Filtrar por Sala</h2>
            <form method="GET" class="filtro">
                <select name="sala" onchange="this.form.submit()">
                    <option value="">Todas as salas</option>
                    <?php foreach ($salas as $sala): ?>
                        <option value="<?php echo $sala['id_sala']; ?>" <?php echo ($sala_filtro == $sala['id_sala']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($sala['nome_sala']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        
        <div class="tabela-section">
            <h2>Lista de Equipamentos</h2>
            <?php if (count($equipamentos) > 0): ?>
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tipo</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Endereço IP</th>
                            <th>Sala</th>
                            
                            <!-- CONDIÇÃO: Mostra o cabeçalho da coluna apenas se for admin -->
                            <?php if ($isAdmin): ?>
                                <th>Criado por</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipamentos as $eq): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($eq['id_equipamento']); ?></td>
                                <td><?php echo htmlspecialchars($eq['tipo']); ?></td>
                                <td><?php echo htmlspecialchars($eq['marca']); ?></td>
                                <td><?php echo htmlspecialchars($eq['modelo']); ?></td>
                                <td><?php echo htmlspecialchars($eq['endereco_ip']); ?></td>
                                <td><?php echo htmlspecialchars($eq['nome_sala'] ?? 'N/A'); ?></td>
                                
                                <!-- CONDIÇÃO: Mostra a célula com o nome apenas se for admin -->
                                <?php if ($isAdmin): ?>
                                    <td><?php echo !empty($eq['criado_por_nome']) ? htmlspecialchars($eq['criado_por_nome']) : 'Desconhecido'; ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhum equipamento registado.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
