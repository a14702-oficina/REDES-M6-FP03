<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config/ligacao.php';

$mensagem = '';

// Processar inserção de técnico
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'inserir') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $contacto = trim($_POST['contacto']);
    
    // Validação
    if (empty($nome) || empty($email) || empty($contacto)) {
        $mensagem = '<div class="erro">Todos os campos são obrigatórios!</div>';
    } else {
        $sql = "INSERT INTO tecnicos (nome, email, contacto) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $nome, $email, $contacto);
        
        if ($stmt->execute()) {
            $mensagem = '<div class="sucesso">Técnico inserido com sucesso!</div>';
        } else {
            $mensagem = '<div class="erro">Erro ao inserir técnico: ' . $conn->error . '</div>';
        }
        $stmt->close();
    }
}

// Obter lista de técnicos
$sql = "SELECT id_tecnico, nome, email, contacto FROM tecnicos ORDER BY nome";
$result = $conn->query($sql);
$tecnicos = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tecnicos[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Técnicos</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Gestão de Técnicos</h1>
        <a href="../index.php" class="btn-voltar">← Voltar ao Menu</a>
        
        <?php echo $mensagem; ?>
        
        <div class="formulario-section">
            <h2>Inserir Novo Técnico</h2>
            <form method="POST" class="formulario">
                <input type="hidden" name="acao" value="inserir">
                
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="contacto">Contacto (Telefone):</label>
                    <input type="text" id="contacto" name="contacto" placeholder="ex: 912345678" required>
                </div>
                
                <button type="submit" class="btn-submit">Inserir Técnico</button>
            </form>
        </div>
        
        <div class="tabela-section">
            <h2>Lista de Técnicos</h2>
            <?php if (count($tecnicos) > 0): ?>
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Contacto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tecnicos as $tecnico): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($tecnico['id_tecnico']); ?></td>
                                <td><?php echo htmlspecialchars($tecnico['nome']); ?></td>
                                <td><?php echo htmlspecialchars($tecnico['email']); ?></td>
                                <td><?php echo htmlspecialchars($tecnico['contacto']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhum técnico registado.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
