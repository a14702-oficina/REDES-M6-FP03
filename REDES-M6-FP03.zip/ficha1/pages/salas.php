<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config/ligacao.php';

$mensagem = '';

// Processar inserção de sala
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'inserir') {
    $nome_sala = trim($_POST['nome_sala']);
    $localizacao = trim($_POST['localizacao']);
    
    // Validação
    if (empty($nome_sala) || empty($localizacao)) {
        $mensagem = '<div class="erro">Todos os campos são obrigatórios!</div>';
    } else {
        $sql = "INSERT INTO salas (nome_sala, localizacao) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
            $mensagem = '<div class="erro">Erro ao preparar query: ' . htmlspecialchars($conn->error) . '</div>';
        } else {
            $stmt->bind_param("ss", $nome_sala, $localizacao);
            
            if ($stmt->execute()) {
                $mensagem = '<div class="sucesso">Sala inserida com sucesso!</div>';
            } else {
                $mensagem = '<div class="erro">Erro ao inserir sala: ' . htmlspecialchars($stmt->error) . '</div>';
            }
            $stmt->close();
        }
    }
}

// Obter lista de salas
$sql = "SELECT id_sala, nome_sala, localizacao FROM salas ORDER BY nome_sala";
$result = $conn->query($sql);
$salas = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $salas[] = $row;
    }
} elseif (!$result) {
    $mensagem .= '<div class="erro">Erro ao consultar salas: ' . htmlspecialchars($conn->error) . '</div>';
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Salas</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Gestão de Salas</h1>
        <a href="../index.php" class="btn-voltar">← Voltar ao Menu</a>
        
        <?php echo $mensagem; ?>
        
        <div class="formulario-section">
            <h2>Inserir Nova Sala</h2>
            <form method="POST" class="formulario">
                <input type="hidden" name="acao" value="inserir">
                
                <div class="form-group">
                    <label for="nome_sala">Nome da Sala:</label>
                    <input type="text" id="nome_sala" name="nome_sala" required>
                </div>
                
                <div class="form-group">
                    <label for="localizacao">Localização:</label>
                    <input type="text" id="localizacao" name="localizacao" required>
                </div>
                
                <button type="submit" class="btn-submit">Inserir Sala</button>
            </form>
        </div>
        
        <div class="tabela-section">
            <h2>Lista de Salas</h2>
            <?php if (count($salas) > 0): ?>
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome da Sala</th>
                            <th>Localização</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($salas as $sala): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($sala['id_sala']); ?></td>
                                <td><?php echo htmlspecialchars($sala['nome_sala']); ?></td>
                                <td><?php echo htmlspecialchars($sala['localizacao']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhuma sala registada.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
