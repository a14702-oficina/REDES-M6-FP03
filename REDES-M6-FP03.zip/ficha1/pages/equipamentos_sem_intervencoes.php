<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config/ligacao.php';

// Query 4: Equipamentos sem intervenções (usando LEFT JOIN)
$sql = "SELECT e.id_equipamento, e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala, COUNT(i.id_intervencao) as num_intervencoes
        FROM equipamentos e 
        LEFT JOIN salas s ON e.id_sala = s.id_sala 
        LEFT JOIN intervencoes i ON e.id_equipamento = i.id_equipamento 
        GROUP BY e.id_equipamento 
        HAVING num_intervencoes = 0 
        ORDER BY s.nome_sala, e.marca";

$result = $conn->query($sql);
$equipamentos = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $equipamentos[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipamentos sem Intervenções</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Equipamentos sem Intervenções</h1>
        <a href="../index.php" class="btn-voltar">← Voltar ao Menu</a>
        
        <div class="equipamentos-sem-intervencoes">
            <p><strong>Nota:</strong> Esta página mostra todos os equipamentos que nunca tiveram qualquer intervenção técnica registada. Utiliza uma query com LEFT JOIN para identificar registos sem correspondência na tabela de intervenções.</p>
        </div>
        
        <div class="tabela-section">
            <h2>Equipamentos sem Histórico de Intervenções</h2>
            <?php if (count($equipamentos) > 0): ?>
                <p><strong>Total de equipamentos sem intervenções:</strong> <?php echo count($equipamentos); ?></p>
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tipo</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Endereço IP</th>
                            <th>Sala</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipamentos as $eq): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($eq['id_equipamento']); ?></td>
                                <td><?php echo htmlspecialchars($eq['tipo']); ?></td>
                                <td><?php echo htmlspecialchars($eq['marca']); ?></td>
                                <td><?php echo htmlspecialchars($eq['modelo']); ?></td>
                                <td><?php echo htmlspecialchars($eq['endereco_ip']); ?></td>
                                <td><?php echo htmlspecialchars($eq['nome_sala'] ?? 'N/A'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p><strong>Excelente!</strong> Todos os equipamentos têm pelo menos uma intervenção registada.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
