<?php
$password_admin = 'admin123';
$password_tecnico = 'albertoribeiro123';

echo "Hash para 'admin123': " . password_hash($password_admin, PASSWORD_DEFAULT) . "\n";
echo "Hash para 'albertoribeiro123': " . password_hash($password_tecnico, PASSWORD_DEFAULT) . "\n";
?>
