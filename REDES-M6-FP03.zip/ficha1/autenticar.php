<?php
session_start();
include 'config/ligacao.php'; // Inclui o ficheiro de ligação à base de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Prepara a query para evitar injeção de SQL
    $stmt = $conn->prepare("SELECT id, username, password, role FROM utilizadores WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        // Verifica a palavra-passe (usar password_verify para senhas hash)
        if ($password === $user["password"]) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["role"] = $user["role"];
            header("Location: index.php");
            exit();
        } else {
            $_SESSION["erro_login"] = "Nome de utilizador ou palavra-passe inválidos.";
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION["erro_login"] = "Nome de utilizador ou palavra-passe inválidos.";
        header("Location: login.php");
        exit();
    }
    $stmt->close();
    $conn->close();
}
?>
